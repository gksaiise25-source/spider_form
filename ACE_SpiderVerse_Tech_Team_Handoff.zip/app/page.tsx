"use client";

import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX, ArrowDownRight, LockKeyhole, X } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import * as THREE from "three";

type Universe = { id: string; name: string; code: string; accent: string; cyan: string; image: string; move: string; note: string };
const universes: Universe[] = [
  { id: "scarlet", name: "Scarlet", code: "E-616", accent: "#f42b2b", cyan: "#53e8ff", image: "/assets/spider-leap.png", move: "Velocity", note: "Built for bold entries." },
  { id: "neon", name: "Neon", code: "E-928", accent: "#ff2bd6", cyan: "#36f4ff", image: "/assets/spider-swing.png", move: "Reflex", note: "Reads the room in a frame." },
  { id: "shadow", name: "Shadow", code: "E-902", accent: "#7758ff", cyan: "#ffcc38", image: "/assets/spider-fall.png", move: "Instinct", note: "Turns pressure into control." },
  { id: "pulse", name: "Pulse", code: "E-1610", accent: "#ff3147", cyan: "#00f0ff", image: "/assets/spider-flip.png", move: "Flow", note: "Makes chaos look effortless." },
];

function DimensionCanvas() {
  const mountRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const mobile = window.innerWidth < 720;
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x03050b, 0.028);
    const camera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.1, 220);
    camera.position.set(0, 2, 18);
    const probe = document.createElement("canvas");
    const probeContext = probe.getContext("webgl2") ?? probe.getContext("webgl");
    if (!probeContext) {
      mount.classList.add("webgl-fallback");
      return;
    }
    probeContext.getExtension("WEBGL_lose_context")?.loseContext();
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: !mobile, powerPreference: "high-performance" });
    } catch {
      mount.classList.add("webgl-fallback");
      return;
    }
    renderer.setPixelRatio(Math.min(devicePixelRatio, mobile ? 1.25 : 1.8));
    renderer.setSize(innerWidth, innerHeight);
    renderer.setClearColor(0x000000, 0);
    mount.appendChild(renderer.domElement);
    const group = new THREE.Group();
    scene.add(group);
    const buildings: THREE.LineSegments[] = [];
    for (let i = 0; i < (mobile ? 22 : 48); i++) {
      const height = 3 + Math.random() * 13;
      const geometry = new THREE.EdgesGeometry(new THREE.BoxGeometry(2 + Math.random() * 3, height, 2 + Math.random() * 4));
      const material = new THREE.LineBasicMaterial({ color: i % 3 === 0 ? 0xf52235 : 0x1ccce8, transparent: true, opacity: 0.08 + Math.random() * 0.1 });
      const building = new THREE.LineSegments(geometry, material);
      building.position.set((i % 2 === 0 ? -1 : 1) * (7 + Math.random() * 20), -4 + height / 2, -Math.random() * 110);
      building.rotation.y = (Math.random() - 0.5) * 0.3;
      group.add(building);
      buildings.push(building);
    }
    const particleCount = mobile ? 240 : 760;
    const points = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      points[i * 3] = (Math.random() - 0.5) * 65;
      points[i * 3 + 1] = (Math.random() - 0.5) * 45;
      points[i * 3 + 2] = -Math.random() * 120;
    }
    const pointGeo = new THREE.BufferGeometry();
    pointGeo.setAttribute("position", new THREE.BufferAttribute(points, 3));
    const particles = new THREE.Points(pointGeo, new THREE.PointsMaterial({ color: 0xe9fbff, size: mobile ? 0.055 : 0.075, transparent: true, opacity: 0.72 }));
    scene.add(particles);
    const rings = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(8 + i * 1.7, 0.015, 6, 100), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x20d9ff : 0xff2340, transparent: true, opacity: 0.14 }));
      ring.rotation.set(Math.PI / 2.4, i * 0.35, i * 0.18);
      ring.position.set(0, 4, -18 - i * 6);
      rings.add(ring);
    }
    scene.add(rings);
    const pointer = { x: 0, y: 0 };
    const onPointer = (event: PointerEvent) => { pointer.x = (event.clientX / innerWidth - 0.5) * 2; pointer.y = (event.clientY / innerHeight - 0.5) * 2; };
    const onResize = () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); };
    window.addEventListener("pointermove", onPointer, { passive: true });
    window.addEventListener("resize", onResize);
    let frame = 0;
    const render = () => {
      const scrollDepth = window.scrollY * 0.008;
      camera.position.x += (pointer.x * 1.35 - camera.position.x) * 0.035;
      camera.position.y += (-pointer.y * 0.85 + 2 - camera.position.y) * 0.035;
      camera.position.z = 18 - (scrollDepth % 62);
      group.rotation.z = reduced ? 0 : pointer.x * 0.012;
      particles.rotation.z += reduced ? 0 : 0.00035;
      rings.rotation.z += reduced ? 0 : 0.0006;
      buildings.forEach((building, index) => {
        if (building.position.z > camera.position.z + 12) building.position.z -= 115;
        (building.material as THREE.LineBasicMaterial).opacity = 0.06 + ((index + Math.floor(scrollDepth)) % 7) * 0.015;
      });
      renderer.render(scene, camera);
      frame = requestAnimationFrame(render);
    };
    render();
    return () => { cancelAnimationFrame(frame); window.removeEventListener("pointermove", onPointer); window.removeEventListener("resize", onResize); renderer.dispose(); mount.removeChild(renderer.domElement); };
  }, []);
  return <div className="dimension-canvas" ref={mountRef} aria-hidden="true" />;
}

function CursorFX() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const trailRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (matchMedia("(pointer: coarse)").matches) return;
    const dot = dotRef.current, ring = ringRef.current, canvas = trailRef.current;
    if (!dot || !ring || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y;
    let points: { x: number; y: number; life: number }[] = [];
    const resize = () => { canvas.width = innerWidth * devicePixelRatio; canvas.height = innerHeight * devicePixelRatio; canvas.style.width = `${innerWidth}px`; canvas.style.height = `${innerHeight}px`; ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0); };
    const move = (e: PointerEvent) => {
      x = e.clientX; y = e.clientY; dot.style.transform = `translate3d(${x}px,${y}px,0)`; points.push({ x, y, life: 1 });
      const interactive = (e.target as HTMLElement).closest("a,button,.universe-card");
      ring.dataset.active = interactive ? "true" : "false"; ring.dataset.label = interactive?.getAttribute("data-cursor") || "";
    };
    let raf = 0;
    const tick = () => {
      rx += (x - rx) * 0.16; ry += (y - ry) * 0.16; ring.style.transform = `translate3d(${rx}px,${ry}px,0)`;
      ctx.clearRect(0, 0, innerWidth, innerHeight); points = points.filter((p) => (p.life -= 0.045) > 0);
      if (points.length > 2) { ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y); points.slice(1).forEach((p) => ctx.lineTo(p.x, p.y)); ctx.strokeStyle = `rgba(110,235,255,${Math.min(0.2, points[0].life * 0.2)})`; ctx.lineWidth = 0.7; ctx.stroke(); }
      raf = requestAnimationFrame(tick);
    };
    resize(); window.addEventListener("resize", resize); window.addEventListener("pointermove", move); tick();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); window.removeEventListener("pointermove", move); };
  }, []);
  return <><canvas ref={trailRef} className="cursor-trail" aria-hidden="true" /><div ref={ringRef} className="cursor-ring" aria-hidden="true"><span /></div><div ref={dotRef} className="cursor-dot" aria-hidden="true" /></>;
}

function UniverseCard({ universe, selected, onSelect }: { universe: Universe; selected: boolean; onSelect: (u: Universe) => void }) {
  const cardRef = useRef<HTMLButtonElement>(null);
  const move = (event: React.PointerEvent<HTMLButtonElement>) => {
    if (matchMedia("(pointer: coarse)").matches) return;
    const card = cardRef.current; if (!card) return;
    const r = card.getBoundingClientRect(), px = (event.clientX - r.left) / r.width - 0.5, py = (event.clientY - r.top) / r.height - 0.5;
    card.style.setProperty("--rx", `${-py * 11}deg`); card.style.setProperty("--ry", `${px * 14}deg`); card.style.setProperty("--mx", `${px * 28}px`); card.style.setProperty("--my", `${py * 28}px`);
  };
  const reset = () => { cardRef.current?.style.setProperty("--rx", "0deg"); cardRef.current?.style.setProperty("--ry", "0deg"); cardRef.current?.style.setProperty("--mx", "0px"); cardRef.current?.style.setProperty("--my", "0px"); };
  return <button ref={cardRef} className={`universe-card ${selected ? "is-selected" : ""}`} style={{ "--card-accent": universe.accent, "--card-cyan": universe.cyan } as React.CSSProperties} onPointerMove={move} onPointerLeave={reset} onClick={() => onSelect(universe)} data-cursor="SELECT" aria-pressed={selected}>
    <span className="card-grid" /><span className="card-number">{universe.code}</span><span className="card-word" aria-hidden="true">{universe.name}</span>
    <img src={universe.image} alt={`${universe.name} Spider-person pose`} className="card-character" loading="lazy" decoding="async" />
    <span className="card-data"><span className="card-kicker">Choose your spider</span><strong>{universe.name}</strong><span>{universe.move} / {universe.note}</span></span><span className="card-corner" />
  </button>;
}

export default function Home() {
  const rootRef = useRef<HTMLElement>(null);
  const [soundOn, setSoundOn] = useState(false), [selected, setSelected] = useState(universes[0]), [portalOpen, setPortalOpen] = useState(false), [fragments, setFragments] = useState<number[]>([]);
  const audioRef = useRef<{ ctx: AudioContext; timer: number } | null>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-depth]").forEach((layer) => { const depth = Number(layer.dataset.depth || 1); gsap.to(layer, { yPercent: -6 * depth, ease: "none", scrollTrigger: { trigger: layer.closest("section"), start: "top bottom", end: "bottom top", scrub: 1.2 } }); });
      gsap.fromTo(".hero-word .letter", { y: "120%", rotateX: -80, opacity: 0 }, { y: "0%", rotateX: 0, opacity: 1, stagger: 0.035, duration: 1.1, ease: "expo.out", delay: 0.3 });
      const mission = gsap.timeline({ scrollTrigger: { trigger: ".mission", start: "top top", end: "+=130%", scrub: 1, pin: true } });
      mission.to(".mission-city", { scale: 1.2, rotate: -3, yPercent: 12, ease: "none" }, 0).to(".mission-headline", { xPercent: -32, ease: "none" }, 0).to(".mission-character", { xPercent: 35, yPercent: -20, rotate: 12, scale: 1.16, ease: "none" }, 0).fromTo(".mission-panel", { clipPath: "polygon(0 0,0 0,0 100%,0 100%)" }, { clipPath: "polygon(0 0,100% 0,92% 100%,0 88%)", ease: "power3.inOut" }, 0.35);
      gsap.utils.toArray<HTMLElement>(".reveal-line").forEach((line) => gsap.from(line, { xPercent: line.dataset.side === "right" ? 35 : -35, opacity: 0, rotate: line.dataset.side === "right" ? 4 : -4, duration: 1, ease: "power4.out", scrollTrigger: { trigger: line, start: "top 83%" } }));
    }, rootRef);
    return () => { ctx.revert(); };
  }, []);
  useEffect(() => { const b: string[] = []; const key = (e: KeyboardEvent) => { b.push(e.key.toLowerCase()); if (b.length > 5) b.shift(); if (b.join("").includes("thwip")) { document.body.classList.add("thwip-mode"); setTimeout(() => document.body.classList.remove("thwip-mode"), 1400); } }; window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key); }, []);
  const toggleSound = () => {
    if (soundOn) { if (audioRef.current) { window.clearInterval(audioRef.current.timer); audioRef.current.ctx.close(); audioRef.current = null; } setSoundOn(false); return; }
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioContextClass(), master = ctx.createGain(); master.gain.value = 0.045; master.connect(ctx.destination);
    const playPulse = () => { const now = ctx.currentTime; [55, 82.4, 110].forEach((freq, i) => { const osc = ctx.createOscillator(), gain = ctx.createGain(); osc.type = i === 0 ? "sine" : "triangle"; osc.frequency.setValueAtTime(freq, now); osc.frequency.exponentialRampToValueAtTime(freq * 0.72, now + 1.7); gain.gain.setValueAtTime(i === 0 ? 0.7 : 0.18, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 1.8); osc.connect(gain).connect(master); osc.start(now + i * 0.04); osc.stop(now + 1.9); }); };
    playPulse(); const timer = window.setInterval(playPulse, 2300); audioRef.current = { ctx, timer }; setSoundOn(true);
  };
  const navigate = (id: string) => {
    const wipe = document.querySelector(".transition-wipe");
    const target = document.getElementById(id);
    if (!wipe || !target) return target?.scrollIntoView({ behavior: "smooth" });
    gsap.set(wipe, { transformOrigin: "0 50%" });
    gsap.to(wipe, { scaleX: 1, duration: 0.48, ease: "power4.inOut", onComplete: () => {
      target.scrollIntoView({ behavior: "auto", block: "start" });
      ScrollTrigger.update();
      gsap.set(wipe, { transformOrigin: "100% 50%" });
      gsap.to(wipe, { scaleX: 0, duration: 0.58, ease: "power4.inOut" });
    } });
  };
  const selectUniverse = (universe: Universe) => { setSelected(universe); document.documentElement.style.setProperty("--red", universe.accent); document.documentElement.style.setProperty("--cyan", universe.cyan); gsap.fromTo(".universe-flash", { opacity: 0.62, scaleX: 0.2 }, { opacity: 0, scaleX: 1, duration: 0.72, ease: "expo.out" }); };
  const collect = (n: number) => setFragments((current) => current.includes(n) ? current : [...current, n]);
  return <main ref={rootRef} className="spider-site">
    <div className="site-shell">
    <DimensionCanvas /><CursorFX /><div className="global-grain" aria-hidden="true" /><div className="halftone-veil" aria-hidden="true" /><div className="transition-wipe" aria-hidden="true"><span>SHIFTING DIMENSIONS</span></div><div className="universe-flash" aria-hidden="true" />
    <header className="site-nav"><button className="ace-mini" onClick={() => navigate("top")} data-cursor="HOME" aria-label="Back to top"><span className="ace-mini-mark">A</span><span>ACE / EVENT 01</span></button><nav aria-label="Primary navigation"><button onClick={() => navigate("mission")}>Mission</button><button onClick={() => navigate("choose")}>Choose</button><button onClick={() => navigate("intel")}>Intel</button></nav><div className="nav-actions"><button className="icon-button" onClick={toggleSound} aria-label={soundOn ? "Mute soundtrack" : "Play soundtrack"}>{soundOn ? <Volume2 size={17} /> : <VolumeX size={17} />}</button><button className="nav-register" onClick={() => navigate("register")} data-cursor="JOIN">Register</button></div></header>
    <section className="hero" id="top"><div className="hero-city" data-depth="0.35" /><div className="hero-lights" data-depth="0.65" /><div className="issue-tag" data-depth="1.4">ISSUE 001 / CMRIT</div><div className="hero-word chromatic" aria-label="Spider">{"SPIDER".split("").map((letter, i) => <span className="letter" key={`${letter}-${i}`}>{letter}</span>)}</div><div className="hero-verse" data-depth="1.1">VERSE</div><img className="hero-character" src="/assets/spider-leap.png" alt="Spider-person leaping toward the viewer" data-depth="1.8" /><div className="hero-copy" data-depth="2.2"><span className="eyebrow">ACE / FIRST CONTACT</span><h1>One event.<br /><em>Infinite</em> versions.</h1><p>The portal is unstable. Your instincts are the only map.</p><button className="graphic-button" onClick={() => navigate("mission")} data-cursor="ENTER"><span>Enter the experience</span><ArrowDownRight /></button></div><div className="hero-coordinates" data-depth="1.55"><span>12.9716° N</span><span>77.5946° E</span><span>EARTH / ACE-01</span></div><button className="fragment fragment-one" onClick={() => collect(1)} aria-label="Collect hidden fragment one" data-cursor="?">⌁</button><span className="scroll-cue">SCROLL TO FALL <i /></span></section>
    <section className="mission" id="mission"><div className="mission-city" /><div className="mission-headline chromatic" aria-hidden="true">THE FALL</div><img className="mission-character" src="/assets/spider-swing.png" alt="Spider-person swinging through the city" loading="lazy" decoding="async" /><article className="mission-panel"><span className="panel-index">01 / THE MISSION</span><h2>When the city drops,<br />what do you reach for?</h2><p>This is not a registration page. It is your first test. Read the signals, choose a universe, and follow the thread.</p><button className="text-link" onClick={() => navigate("choose")} data-cursor="NEXT">Choose your Spider <span>↗</span></button></article><div className="speed-lines" aria-hidden="true" /><span className="sound-word" aria-hidden="true">THWIP!</span></section>
    <section className="choose" id="choose"><div className="choose-backdrop" aria-hidden="true">CHOOSE</div><header className="section-heading reveal-line"><span className="eyebrow">02 / CHARACTER SELECT</span><h2>Pick your <em>dimension.</em></h2><p>Hover to inspect. Click to shift the entire universe.</p></header><div className="universe-stage">{universes.map((universe) => <UniverseCard key={universe.id} universe={universe} selected={selected.id === universe.id} onSelect={selectUniverse} />)}</div><div className="selected-readout reveal-line" data-side="right"><span>ACTIVE DIMENSION</span><strong>{selected.code} / {selected.name.toUpperCase()}</strong><i style={{ background: selected.accent }} /></div><button className="fragment fragment-two" onClick={() => collect(2)} aria-label="Collect hidden fragment two" data-cursor="?">⌬</button></section>
    <section className="intel" id="intel"><div className="intel-title reveal-line"><span>CLASSIFIED / ACE FILE</span><h2>Event <span>intel.</span></h2></div><div className="intel-grid"><article className="intel-card card-date reveal-line"><span className="intel-no">A / 01</span><small>WHEN</small><strong>DATE<br /><i>CLASSIFIED</i></strong><p>Signal incoming. Reveal scheduled.</p></article><article className="intel-card card-place reveal-line" data-side="right"><span className="intel-no">B / 02</span><small>WHERE</small><strong>PORTAL<br /><i>UNLOCKING</i></strong><p>Coordinates will stabilize soon.</p></article><article className="intel-card card-team reveal-line"><span className="intel-no">C / 03</span><small>WHO</small><strong>BUILD YOUR<br /><i>CREW</i></strong><p>Team protocol remains encrypted.</p></article></div><div className="web-bridge" aria-hidden="true"><span /><span /><span /></div><button className="fragment fragment-three" onClick={() => collect(3)} aria-label="Collect hidden fragment three" data-cursor="?">蛛</button><div className={`fragment-status ${fragments.length === 3 ? "complete" : ""}`}><span>SECRET SIGNAL</span><strong>{fragments.length}/3 FRAGMENTS</strong><p>{fragments.length === 3 ? "EARTH-ACE // The first clue is hidden in plain sight." : "Three anomalies are embedded in this universe."}</p></div></section>
    <section className="register" id="register"><div className="portal-rings" aria-hidden="true"><i /><i /><i /><i /></div><img className="register-character" src="/assets/spider-flip.png" alt="Spider-person flipping through a dimensional portal" data-depth="1.7" loading="lazy" decoding="async" /><div className="register-copy" data-depth="2.2"><span className="eyebrow">FINAL CHECKPOINT</span><h2>Ready to enter<br />the <em>Spider-Verse?</em></h2><p>Registration coordinates are being synchronized.</p><button className="portal-button" onClick={() => setPortalOpen(true)} data-cursor="JOIN"><span>Open registration portal</span><b>↗</b></button></div></section>
    <footer><span>ACE CLUB / CMRIT</span><strong>WITH GREAT IDEAS COME<br />GREAT FIRST EVENTS.</strong><span>EARTH-ACE / 2026</span></footer>
    {portalOpen && <div className="portal-modal" role="dialog" aria-modal="true" aria-labelledby="portal-title"><button className="portal-backdrop" onClick={() => setPortalOpen(false)} aria-label="Close registration panel" /><div className="portal-panel"><button className="modal-close" onClick={() => setPortalOpen(false)} aria-label="Close"><X /></button><span className="portal-lock"><LockKeyhole /></span><span className="eyebrow">PORTAL STATUS / ENCRYPTED</span><h2 id="portal-title">Registration<br />opens soon.</h2><p>The Google Form has not been linked yet. Once the final coordinates arrive, this control will launch it instantly.</p><button className="graphic-button" onClick={() => setPortalOpen(false)}><span>Return to this dimension</span></button></div></div>}
    <div className="thwip-easter" aria-hidden="true">THWIP!</div>
    </div>
  </main>;
}
