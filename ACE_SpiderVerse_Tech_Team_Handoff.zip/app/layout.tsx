import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ACE: Into the Spider-Verse",
  description: "Enter ACE Club's interactive dimensional event experience.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased">{children}</body>
    </html>
  );
}
